# Audio Hacker Arduino Library

This library provides the API to control the nootropic design Audio Hacker Shield. For all product
information and detailed API documentation, [see the Audio Hacker product page](https://nootropicdesign.com/audiohacker/).
